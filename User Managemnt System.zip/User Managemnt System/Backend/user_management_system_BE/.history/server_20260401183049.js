require("dotenv").config();
const express = require('express');
const app = express();
const cors = require('cors');
const port = 5000;
const host = 'localhost';
const mongoose = require('mongoose');
const db = require('./database/mongoose');
const router = require('../user_management_system_BE/routes/router');


app.use(cors());

app.use(express.json());

const connect = async() => {
    try{
        await db.connect();
        console.log("Connected to MongoDB");

    }catch(error){
        console.log|("MongoDB Error: ",error);
    }
}

connect();

const server = app.listen(port,host, () => {
    console.log(`Node server is listening to ${server.address().port}`);
})

//Routes
app.use("/api",router);
