const mongoose = require("mongoose");

require("dotenv").config;

const {MONGODB_URI, MONGODB_USER, MONGODB_PASSWORD, MONGODB_DB, MONGODB_HOST} = process.env;

function buildUri() {
    if(MONGODB_URI && MONGODB_URI.trim() !== ""){
        return MONGODB_URI;
    }

    if(!MONGODB_USER || !MONGODB_PASSWORD || !MONGODB_DB || !MONGODB_HOST) {
        throw new Error("Missing MongoDb env vars");
    }

        const  user = encodeURIComponent(MONGODB_USER);
        const password = encodeURIComponent(MONGODB_PASSWORD);

        return `mongodb+srv://${user}:${password}@${MONGODB_HOST}/${MONGODB_DB}?retryWrites=true&w=majority`;
}

const uri = buildUri();

async function connect() {
    try{

        await mongoose.connect(uri);
        console.log("MongoDB Connected ", mongoose.connection.name);
    }catch(error){
        console.error("MongDB error ",error);
        throw error;

    }
}

function disconnect() {
    return mongoose.disconnect();
}

module.exports = {
    connect,
    disconnect,
    mongoose,
};