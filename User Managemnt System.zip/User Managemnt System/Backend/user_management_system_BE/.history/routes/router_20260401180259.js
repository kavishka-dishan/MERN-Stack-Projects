const express = require("express");
const router = express.Router();
const controller = require('../controllers/user_controller');

router.get('/users', controller.getUsers);
router.post('/createUser', controller.addUser);
router.patch('/updateUser', controller.updateUser);
router.delete('/deleteUser', controller.deleteUser);

module.exports = router;