const User = require("../models/model");

//Get Users
 exports.getUsers = async (req, res, next) => {
    try{

        const users = await User.find()

        if(!users || users.length == 0 ){
            return res.status(200).json({
                success:  true,
                message: "No watches available",
                data:[],
            });

            return res.status.json({
                success: true,
                message: "Watches fetched Successfully",
                data:users,
            });
        }

    }catch(error){
        next(error);
    }
 };

 //Add User
 exports.addUser = async (req,res,next) => {
    try{
        const {id, name} = req.body;
        //basic validations
        if( !id || !name){
            return res.status(200).json({
                success:false,
                message:"ID and Name are Required",
            })
        };

        //Check Id already exists
        const exists = await User.fineOne({id});
        if(exists){
            return res.status(400).json({
                success:false,
                message:"ID Already exists",
            })
        }

        ///Add user
        const user = new User({ id, name});
        await user.save();
        return res.status(201).json({
            success: true,
            message: "New user Added Successfully"
        });

    }catch(error){
        next(error);
    }
 };


 //Update User
 exports.updateUser = async(req,res,next) => {
    try{

    }catch(error){
        next(error);
    }
 }


 //Delete User
 exports.deleteUser = async(req,res,next) =>{
    try{

    }catch(error){
        next(error);
    }
 }