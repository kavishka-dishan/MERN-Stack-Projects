const User = require("../models/model");

//Get Users
 exports.getUsers = async (req, res, next) => {
    try{

        const users = await User.find()

        if(!users || users.length == 0 ){
            return res.status(200).json({
                success:  true,
                message: "No Users available",
                data:[],
            });
        }
            return res.status(200).json({
                success: true,
                message: "Users fetched Successfully",
                data:users,
            });
        

    }catch(error){
        next(error);
    }
 };

 //Add User
 exports.addUser = async (req,res,next) => {
    try{
        const {id, name} = req.body;
        //basic validations
        if( !id || !name){
            return res.status(200).json({
                success:false,
                message:"ID and Name are Required",
            })
        };

        //Check Id already exists
        {/*const exists = await User.findOne({id});
        if(exists){
            return res.status(400).json({
                success:false,
                message:"ID Already exists",
            })
        } */}

        ///Add user
        const user = new User({ id, name});
        await user.save();
        return res.status(201).json({
            success: true,
            message: "New user Added Successfully"
        });

    }catch(error){
        next(error);
    }
 };


 //Update User
 exports.updateUser = async(req,res,next) => {
    try{
        const {id, name} = req.body;
        if( !id){
            return res.status(200).json({
                success:false,
                message:"Watch Not Found",
            })
        };
   
        if( name == undefined){
            return res.status(400).json({
                success:false,
                message:"Please provide at name to continue",
            })
        };

        await User.updateOne({id:id}, {$set: {name: name}})
        return res.status(200).json({
                success:true,
                message:"User updated Successfully",
            })

    }catch(error){
        next(error);
    }
 }


 //Delete User
 exports.deleteUser = async(req,res,next) => {
    try{
        
        const id = req.params;
        const deleted = await User.findOneAndDelete(id);
        if(!deleted){
            return res.status(404).json({
                success:false,
                message:"User not Found",
            })
        };

        return res.status(200).json({
            success:true,
            message:"User deleted Successfully",
        });
      
    }catch(error){
        next(error);
    }
 }