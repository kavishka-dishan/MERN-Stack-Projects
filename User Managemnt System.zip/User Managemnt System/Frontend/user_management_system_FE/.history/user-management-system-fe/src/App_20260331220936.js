import logo from './logo.svg';
import './App.css';
import { Routes, Route } from "react-router-dom";
import Welcome from './pages/Welcome';
import UserManagement from './pages/UserManagement';

function App() {
  return (
    <Routes>
      <Route path="/" element={<Welcome/>}/>
      <Route path="/users" element={UserManagement}/>
    </Routes>
    
  );
}

export default App;
