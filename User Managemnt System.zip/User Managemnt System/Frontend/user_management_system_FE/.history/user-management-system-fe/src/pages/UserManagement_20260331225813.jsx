import React from "react";
import UserForm from "../components/UserForm";

const UserManagement = () => {

    return(

        <div className="min-h-screen p-6 bg-gray-100">
            <div className="flex flex-col gap-4 md:flex-row">

                {/*Left side form */}
                <div className="items-center min-h-screen p-5 bg-white rounded-md shadow-xl md:w-1/4">
                        <UserForm/>
                </div>

                {/*Right side Table */}
                <div>

                </div>

            </div>

        </div>

    );

}

export default UserManagement;