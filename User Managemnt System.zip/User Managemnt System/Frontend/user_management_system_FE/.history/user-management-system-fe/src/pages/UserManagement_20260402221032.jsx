import React, { useEffect, useState } from "react";
import UserForm from "../components/UserForm";
import UserTable from "../components/UserTable";
import Axios from "axios";

const UserManagement = () => {

    const [users, setUsers] = useState([]);
    const[submitted, setSubmitted] = useState(false);
    const[selectedUser, setSelectedUser] = useState({});
    const[isEdit, setIsEdit] = useState(false);

    //component did mount - page ek load krddi  call wenwa 
    useEffect(() => {
        getUsers(); 
    },[]);

    ///Get Users
    const getUsers = () => {
      Axios.get('http://localhost:5000/api/users')
            .then(response => {
                setUsers(response.data?.data || []);
            })
            .catch(error => {
                console.error("Error: ",error);
            })
    };


    ///Add User
    const addUser = (data) => {
        setSubmitted(true);

        const payload = {
            id:data.id,
            name:data.name,
        }

                   
        Axios.post('http://localhost:5000/api/createUser' , payload)
        .then(() => {
            getUsers();
            setSubmitted(false);
            isEdit(false);
        })
        .catch(error => {
            console.error("Error: ",error);
        });

    }

    //Update User
    const updateUser = (data) => {
        setSubmitted(true);

        const payload = {
            id:data.id,
            name:data.name,
        }

        Axios.patch('http://localhost:5000/api/updateUser', payload)
        .then(() => {
            getUsers();
            setSubmitted(false);
            isEdit(false);
        })
        .catch(error => {
            console.error("Error: ",error);
        });
    }


    //Delete User
    const deleteUser = (id) => {
        Axios.delete('http://localhost:5000/api/deleteUser/id')
        .then(()=>{
            getUsers();
        })
        .catch(error => {
            console.error("Error: ",error);
        });
    }

    return(

        <div className="min-h-screen p-6 bg-green-300 ">
            <div className="flex flex-col max-w-6xl gap-4 mx-auto md:flex-row">

                {/*Left side form */}
                <div className="sticky w-full p-5 bg-white rounded-md shadow-xl md:w-1/3 top-6 h-fit">
                        <UserForm
                            addUser={addUser}
                            submitted={submitted} /// form ek clear wenna user add unt passe
                            data={selectedUser}
                            isEdit = {isEdit}
                            updateUser = {updateUser}
                       />
                </div>

                {/*Right side Table */}
                <div className="justify-center p-4 overflow-x-auto bg-white rounded shadow-xl md:w-2/3 ">
                    <UserTable
                        rows = {users}
                        selectedUser = {data => {
                            setSelectedUser(data);
                            setIsEdit(true);   
                        }}
                        deleteUser = {data => window.confirm("Are you Suer? ") && deleteUser(data.id)} 
                    />
                </div>

            </div>

        </div>

    );

}

export default UserManagement;