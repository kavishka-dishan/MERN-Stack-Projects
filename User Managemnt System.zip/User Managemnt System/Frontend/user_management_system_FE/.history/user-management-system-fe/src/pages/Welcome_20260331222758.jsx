import React from "react";
import { useNavigate } from "react-router-dom";

const Welcome = () => {

    const navigate = useNavigate();

    return(

        <div className="flex flex-col items-center justify-center h-screen bg-gray-100">
                <h1 className="mb-6 text-4xl font-semibold">
                Welcome to User Management System
                </h1>

                <button
                onClick={() => navigate('/users')}
                className="px-6 py-3 text-white bg-blue-500 rounded hover:bg-blue-600"
                >
                    Go to Users
                </button>
        </div>
    );


}

export default Welcome;