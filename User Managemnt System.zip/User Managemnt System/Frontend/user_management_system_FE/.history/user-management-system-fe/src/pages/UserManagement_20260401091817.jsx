import React from "react";
import UserForm from "../components/UserForm";
import UserTable from "../components/UserTable";

const UserManagement = () => {

    return(

        <div className="min-h-screen p-6 bg-gray-100">
            <div className="flex flex-col max-w-6xl gap-4 mx-auto md:flex-row">

                {/*Left side form */}
                <div className="w-full p-5 bg-white rounded-md shadow-xl md:w-2/3 lg:w-1/4">
                        <UserForm/>
                </div>

                {/*Right side Table */}
                <div className="justify-center p-4 overflow-x-auto bg-white rounded shadow-xl md:w-2/3 lg:w-3/4">
                    <UserTable/>
                </div>

            </div>

        </div>

    );

}

export default UserManagement;