import React from "react";

const UserManagement = () => {

    return(

        <div className="min-h-screen p-6 bg-gray-100">
            <div className="flex flex-col gap-4 md:flex-row">

                {/*Left side form */}
                <div>

                </div>

                {/*Right side Table */}
                <div>

                </div>

            </div>

        </div>

    );

}

export default UserManagement;