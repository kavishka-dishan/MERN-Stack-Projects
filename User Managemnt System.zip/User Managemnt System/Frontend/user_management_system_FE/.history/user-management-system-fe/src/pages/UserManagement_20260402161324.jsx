import React, { useEffect, useState } from "react";
import UserForm from "../components/UserForm";
import UserTable from "../components/UserTable";
import Axios from "axios";

const UserManagement = () => {

    const [users, setUsers] = useState([]);
    const[submitted, setSubmitted] = useState(false);

    //component did mount - page ek load krddi  call wenwa 
    useEffect(() => {
        getUsers();
    },[]);

    ///Get Users
    const getUsers = () => {
      Axios.get('http://localhost:5000/api/users')
            .then(response => {
                setUsers(response.data?.data || []);
            })
            .catch(error => {
                console.error("Error: ",error);
            })
    };


    ///Add User
    const addUser = (data) => {
        setSubmitted(true);

        const payload = {
            id:data.id,
            name:data.name,
        }

        try{
            Axios.post('http://localhost:5000/api/createUser' , payload)
            getUsers();
            setSubmitted(false);

        }catch(error){
            console.error("Error: ",error);

        }

    };

    return(

        <div className="min-h-screen p-6 bg-gray-100">
            <div className="flex flex-col max-w-6xl gap-4 mx-auto md:flex-row">

                {/*Left side form */}
                <div className="w-full p-5 bg-white rounded-md shadow-xl md:w-1/3 ">
                        <UserForm
                            addUser={addUser}
                            submitted={submitted} /// form ek clear wenna user add unt passe
                        />
                </div>

                {/*Right side Table */}
                <div className="justify-center p-4 overflow-x-auto bg-white rounded shadow-xl md:w-2/3 ">
                    <UserTable
                        rows = {users}
                    />
                </div>

            </div>

        </div>

    );

}

export default UserManagement;