import React from "react";
import { useNavigate } from "react-router-dom";

const Welcome = () => {

    const navigate = useNavigate();

    return(

        <div className="flex flex-col items-center justify-center h-screen bg-gray-100">
            <h1>Welcome to User Management System</h1>
        </div>
    );


}

export default Welcome;