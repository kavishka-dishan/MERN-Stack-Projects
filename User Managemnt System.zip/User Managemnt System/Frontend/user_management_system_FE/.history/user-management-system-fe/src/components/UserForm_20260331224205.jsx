import React from "react";

const UserForm = () => {

    return(

        <form>

            <h2>User Form</h2>

            <input
                type="text"
                placeholder="User ID"
                value={""}
                onChange={""}
                className="w-full p-2 mb-3 border"
            />

        </form>

    );
}

export default UserForm;