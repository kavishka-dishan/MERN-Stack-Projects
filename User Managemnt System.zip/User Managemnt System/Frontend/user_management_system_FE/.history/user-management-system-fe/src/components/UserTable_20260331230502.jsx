import React from "react";

const UserTable = () => {
    return(

        <div>
                <h2 className="mb-4 text-xl font-bold">
                User List
                </h2>

                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                </table>
        </div>

    );
}

export default UserTable;