import React from "react";

const users : {
    {
        "id": 1,
        "name":"kavishka"
    }
}

const UserTable = () => {
    return(

        <div>
                <h2 className="mb-4 text-2xl font-semibold text-center">
                User List
                </h2>

                <table className="w-full border">
                    <thead>
                        <tr className="bg-gray-200">
                            <th className="p-2 border">ID</th>
                            <th className="p-2 border">Name</th>
                            <th className="p-2 border">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
        </div>

    );
}

export default UserTable;