import React from "react";

const UserTable = ({rows,selectedUser,deleteUser}) => {
    return(

        <div>
                <h2 className="mb-4 text-2xl font-semibold text-center">
                User List
                </h2>

                <table className="w-full border">
                    <thead>
                        <tr className="bg-gray-200">
                            <th className="p-2 border">ID</th>
                            <th className="p-2 border">Name</th>
                            <th className="p-2 border">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {rows.map((user) => (
                        <tr key={user.id}>
                            <td className="p-2 border">{user.id}</td>
                            <td className="p-2 border">{user.name}</td>

                            <td className="flex items-center justify-center p-2 space-x-2 border">
                                <button className="px-2 py-1 text-white bg-yellow-500 rounded"
                                onClick={() => selectedUser({id:user.id, name:user.name})}
                                >
                                    Update
                                    </button>

                                <button className="px-2 py-1 text-white bg-red-500 rounded"
                                onClick={() => deleteUser({id:user.id})}
                                >
                                    Delete
                                    </button>
                            </td>
                        </tr>
                        ))}
                    </tbody>
                </table>
        </div>

    );
}

export default UserTable;