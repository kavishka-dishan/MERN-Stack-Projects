import React, { useEffect, useState } from "react";

const UserForm = ({addUser,submitted}) => {

    const [id,setId] = useState(0);
    const[name,setName] = useState('');

    return(

        <form>

            <h2 className="mb-5 text-2xl font-semibold text-center">User Form</h2>

            <input
                type="text"
                placeholder="User ID"
                value={id}
                onChange={e => setId(e.target.value)}
                className="w-full p-2 mb-5 border"
            />
            
            <input
                type="text"
                placeholder="User Name"
                value={name}
                onChange={e => setName(e.target.value)}
                className="w-full p-2 mb-5 border"
            />

            <button
                type="submit"
                onClick={(e) => {
                    e.preventDefault()
                    addUser({id:id, name:name});
                }}
                className="w-full px-4 py-2 text-white bg-green-500 rounded-lg"
            >
                Add User
            </button>

        </form>

    );
}

export default UserForm;