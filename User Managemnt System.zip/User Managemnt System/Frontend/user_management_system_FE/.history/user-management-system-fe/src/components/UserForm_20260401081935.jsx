import React from "react";

const UserForm = () => {

    return(

        <form>

            <h2 className="mb-5 text-2xl font-semibold text-center">User Form</h2>

            <input
                type="text"
                placeholder="User ID"
                value={""}
                onChange={""}
                className="w-full p-2 mb-5 border"
            />
            
            <input
                type="text"
                placeholder="User Name"
                value={""}
                onChange={""}
                className="w-full p-2 mb-5 border"
            />

            <button
                type="submit"
                onClick={""}
                className="w-full px-4 py-2 text-white bg-green-500 rounded-lg"
            >
                Add User
            </button>

        </form>

    );
}

export default UserForm;