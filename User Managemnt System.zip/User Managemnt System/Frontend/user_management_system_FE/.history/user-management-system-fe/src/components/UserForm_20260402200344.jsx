import React, { useEffect, useState } from "react";

const UserForm = ({addUser,submitted,data,isEdit,updateUser}) => {

    const [id,setId] = useState();
    const[name,setName] = useState('');

    useEffect(()=>{
        if(!submitted){
            setId();
            setName(" ");
        }
    },[submitted]);


    useEffect(() => {
        if(data && data.id && data.id !== 0){
            setId(data.id);
            setName(data.name);    
        }
    },[data]);
     
    return(

        <form>

            <h2 className="mb-5 text-2xl font-semibold text-center">User Form</h2>

            {/*ID Field */}
            <label className="block mb-1 text-sm font-medium text-gray-900">
                User ID
            </label>
            <input
                type="text"
                value={id}
                onChange={e => setId(e.target.value)}
                className="w-full p-2 mb-5 border"
            />

            {/*Name Field*/}
            <label className="block mb-1 text-sm font-medium text-gray-900">
                User Name
            </label>
            
            <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                className="w-full p-2 mb-5 border"
            />

            <button
                type="submit"
                onClick={(e) => {
                    e.preventDefault()
                    isEdit? updateUser({id:id, name:name}):addUser({id:id, name:name});
                }}
                className="w-full px-4 py-2 text-white bg-green-500 rounded-lg"
            >
                {

                    isEdit? 'Update' : 'Add'

                }
            </button>

        </form>

    );
}

export default UserForm;