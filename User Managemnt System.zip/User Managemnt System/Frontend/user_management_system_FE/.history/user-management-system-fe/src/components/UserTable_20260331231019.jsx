import React from "react";

const UserTable = () => {
    return(

        <div>
                <h2 className="mb-4 text-xl font-bold">
                User List
                </h2>

                <table className="w-full border">
                    <thead>
                        <tr className="bg-gray-200">
                            <th className="p-2 border">ID</th>
                            <th className="p-2 border">Name</th>
                            <th className="border-p2">Action</th>
                        </tr>
                    </thead>
                </table>
        </div>

    );
}

export default UserTable;