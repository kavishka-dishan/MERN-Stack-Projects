import User from "../models/user.model";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

///Register
export const register = async(req, res) => {
    try{
        const {name, email, password} = req.body;

        const hashedPassword =  await bcrypt.hash(password,10);

        const user = new User({
            name,
            email,
            password:hashedPassword,
        })

        await user.save();
        res.json("User Registered");

    }catch(error){
        res.status(500).json(error);
    } 
}

///Login
export const login = async(req, res) => {
    try{

        const {email, password} = req.body;
        const user = await User.findOne({email});

        //email checking
        if(!user){
            res.status(400).json({
                success:false,
                message:"User not found",
            });
        }

        //password checking
        const isMatch = await bcrypt.compare(password,user.password);

        if(!isMatch){
            return res.status(400).json({
                success:false,
                message:"Invalid credentials",
            });
        }

        const token = jwt.sign({id: user.id}, "secretkey" ,{
            expiresIn: "1d",
        });

        res.json({token});

    }catch(error){
        res.status(500).json(error);
    }
}