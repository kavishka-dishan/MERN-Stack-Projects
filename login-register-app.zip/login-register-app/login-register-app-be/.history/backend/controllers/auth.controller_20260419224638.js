import User from "../models/user.model";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

///Register
export const register = async(req, res) => {
    try{
        const {name, email, password} = req.body;

        const hashedPassword =  await bcrypt.hash(password,10);

        const user = new User({
            name,
            email,
            password:hashedPassword,
        })

        await user.save();
        res.json("User Registered");

    }catch(error){
        res.status(500).json(error);
    } 
}