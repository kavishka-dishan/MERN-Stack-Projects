import dotenv from "dotenv";
dotenv.config();
import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import authRoutes from "./routes/authRoutes.js";

const app = express();

app.use(express.json());
app.use(cors());

const PORT = process.env.PORT || 5000;
const HOST = process.env.HOST || "localhost";


  app.listen(PORT, () => {
    console.log(`Server running on http://${HOST}:${PORT}`);
  });


const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log("MongoDB Connected");
  } catch (error) {
    console.log(error);
  }
};

app.use("/api/auth", authRoutes);

export default connectDB();
