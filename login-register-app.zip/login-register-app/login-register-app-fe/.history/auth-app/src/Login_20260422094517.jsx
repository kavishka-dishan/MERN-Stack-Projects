import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function Login() {
  const [data, setData] = useState({
    email: "",
    password: "",
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    setData({ ...data, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const res = await axios.post(
        "http://localhost:5000/api/auth/login",
        data,
      );

      setData({
        email: "",
        password: "",
      });

      localStorage.setItem("token", res.data.token);

      navigate("/welcome"); ///redirect
    } catch (error) {
      ///check error response from backend
      if (error.response && error.response.message) {
        alert(error.res.data.message); //backend message
      } else {
        alert("Login Failed Please check your email and password");
      }
    }
  };

  return (
    <div className="flex items-center justify-center h-screen bg-gradient-to-r from-blue-500 to-cyan-500">
      <form
        className="p-8 bg-white shadow-lg rounded-2xl w-80"
        onSubmit={handleSubmit}
      >
        <h2 className="mb-6 text-2xl font-bold text-center">Login</h2>

        <input
          name="email"
          type="String"
          value={data.name}
          onChange={handleChange}
          placeholder="Email"
          className="w-full p-2 mb-3 border rounded-lg"
        />

        <input
          name="password"
          type="password"
          value={data.password}
          onChange={handleChange}
          placeholder="Password"
          className="w-full p-2 mb-4 border rounded-lg"
        />

        <button className="w-full p-2 text-white bg-blue-600 rounded-lg hover:bg-blue-700">
          Login
        </button>

        <p className="mt-3 text-sm text-center">
          No account?{" "}
          <a href="/register" className="text-blue-600">
            Register
          </a>
        </p>
      </form>
    </div>
  );
}

export default Login;
