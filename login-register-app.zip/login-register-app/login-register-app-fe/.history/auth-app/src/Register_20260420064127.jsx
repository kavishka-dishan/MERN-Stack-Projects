import { useState } from "react";
import axios from "axios";

function Register() {
  const [data, setData] = useState({
    name: "",
    email: "",
    password: "",
  });

  const handleChange = (e) => {
    setData({ ...data, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:5000/api/auth/register", data);
    alert("Registered Successfully!");
  };

  return (
    <div className="h-screen flex items-center justify-center bg-gradient-to-r from-purple-500 to-indigo-500">
      <form
        onSubmit={handleSubmit}
        className="bg-white p-8 rounded-2xl shadow-lg w-80"
      >
        <h2 className="text-2xl font-bold text-center mb-6">Register</h2>

        <input
          name="name"
          onChange={handleChange}
          placeholder="Name"
          className="w-full p-2 mb-3 border rounded-lg"
        />

        <input
          name="email"
          onChange={handleChange}
          placeholder="Email"
          className="w-full p-2 mb-3 border rounded-lg"
        />

        <input
          name="password"
          type="password"
          onChange={handleChange}
          placeholder="Password"
          className="w-full p-2 mb-4 border rounded-lg"
        />

        <button className="w-full bg-purple-600 text-white p-2 rounded-lg hover:bg-purple-700">
          Register
        </button>
      </form>
    </div>
  );
}

export default Register;