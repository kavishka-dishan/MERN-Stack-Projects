import { useNavigate } from "react-router-dom";


function Welcome() {

  const navigate = useNavigate();

  const handleLogout = () => {
      localStorage.removeItem("token"); //delete token
      navigate("/login");   // redirect to login page
  };

  return (
    <div className="flex items-center justify-center h-screen bg-gradient-to-r from-green-400 to-emerald-500">
      <div className="p-10 text-center bg-white shadow-lg rounded-2xl">
        <h1 className="mb-4 text-3xl font-bold">Welcome 🎉</h1>
        <p className="text-gray-600">You are successfully logged in!</p>

        <button
          onClick={handleLogout}
          className="px-5 py-2 mt-5 font-semibold text-white duration-200 bg-red-500 rounded-lg shadow-md hover:bg-red-600 transaction "
        >
          Logout
        </button>
      </div>
    </div>
  );
}

export default Welcome;