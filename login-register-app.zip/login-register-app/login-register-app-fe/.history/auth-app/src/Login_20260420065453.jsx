import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function Login() {
  const [data, setData] = useState({
    email: "",
    password: "",
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    setData({ ...data, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const res = await axios.post(
      "http://localhost:5000/api/auth/login",
      data
    );

    localStorage.setItem("token", res.data.token);

    navigate("/welcome"); //redirect
  };

  return (
    <div className="h-screen flex items-center justify-center bg-gradient-to-r from-blue-500 to-cyan-500">
      <form className="bg-white p-8 rounded-2xl shadow-lg w-80" onSubmit={handleSubmit}>
        <h2 className="text-2xl font-bold text-center mb-6">Login</h2>

        <input
          name="email"
          onChange={handleChange}
          placeholder="Email"
          className="w-full p-2 mb-3 border rounded-lg"
        />

        <input
          name="password"
          type="password"
          onChange={handleChange}
          placeholder="Password"
          className="w-full p-2 mb-4 border rounded-lg"
        />

        <button className="w-full bg-blue-600 text-white p-2 rounded-lg hover:bg-blue-700">
          Login
        </button>
      </form>
    </div>
  );
}

export default Login;