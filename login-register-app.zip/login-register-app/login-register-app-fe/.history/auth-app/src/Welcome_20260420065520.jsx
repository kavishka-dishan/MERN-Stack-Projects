function Welcome() {
  return (
    <div className="h-screen flex items-center justify-center bg-gradient-to-r from-green-400 to-emerald-500">
      <div className="bg-white p-10 rounded-2xl shadow-lg text-center">
        <h1 className="text-3xl font-bold mb-4">Welcome 🎉</h1>
        <p className="text-gray-600">You are successfully logged in!</p>
      </div>
    </div>
  );
}

export default Welcome;