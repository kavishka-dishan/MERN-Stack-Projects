import { useNavigate } from "react-router-dom";
import { useState } from "react";
import axios from "axios";

function Register() {
  const navigate = useNavigate();

  const [data, setData] = useState({
    name: "",
    email: "",
    password: "",
  });

  const handleChange = (e) => {
    setData({ ...data, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:5000/api/auth/register", data);
    console.log(data);
    alert("Registered Successfully!");

    //form clear
    setData({
      name: "",
      email: "",
      password: "",
    });
  };

  return (
    <div className="flex items-center justify-center h-screen bg-gradient-to-r from-purple-500 to-indigo-500">
      <form
        onSubmit={handleSubmit}
        className="p-8 bg-white shadow-lg rounded-2xl w-80"
      >
        <h2 className="mb-6 text-2xl font-bold text-center">Register</h2>

        <input
          name="name"
          type="String"
          onChange={handleChange}
          value={data.name}
          placeholder="Name"
          className="w-full p-2 mb-3 border rounded-lg"
        />

        <input
          name="email"
          type="email"
          value={data.email}
          onChange={handleChange}
          placeholder="Email"
          className="w-full p-2 mb-3 border rounded-lg"
        />

        <input
          name="password"
          type="password"
          value={data.password}
          onChange={handleChange}
          placeholder="Password"
          className="w-full p-2 mb-4 border rounded-lg"
        />

        <button className="w-full p-2 text-white bg-purple-600 rounded-lg hover:bg-purple-700">
          Register
        </button>

        <button
          type="button"
          onClick={() => navigate("/")}
          className="w-full p-2 mt-3 text-purple-600 border border-purple-600 rounded-lg hover:bg-purple-100"
        >
          Go to Login
        </button>
      </form>
    </div>
  );
}

export default Register;
